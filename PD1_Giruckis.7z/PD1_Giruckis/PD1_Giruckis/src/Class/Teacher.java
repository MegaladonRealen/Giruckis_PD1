/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

/**
 *
 * @author Roman Giruckis
 */
public class Teacher extends User {
    public Teacher(String fullName, String login, String password) {
        super(fullName, login, password);
    }

    public void StartTest() {}
    public void reviewAnswers() {}
    public void StartTraining() {}
}

