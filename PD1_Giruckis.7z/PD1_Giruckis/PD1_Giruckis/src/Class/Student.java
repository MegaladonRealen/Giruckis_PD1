/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

/**
 *
 * @author Roman Giruckis
 */
public class Student extends User {
    private int totalQuestions = 0;
    private int correctAnswers = 0;

    public Student(String fullName, String login, String password) {
        super(fullName, login, password);
    }

    public void submitAnswer(Question question, String givenAnswer) {
        totalQuestions++;
        if (question.isCorrect(givenAnswer)) {
            correctAnswers++;
        }
    }

    public void resetScore() {
        totalQuestions = 0;
        correctAnswers = 0;
    }

    public double calculateScore() {
        return totalQuestions == 0 ? 0.0 : (double) correctAnswers / totalQuestions;
    }

    Double User() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
