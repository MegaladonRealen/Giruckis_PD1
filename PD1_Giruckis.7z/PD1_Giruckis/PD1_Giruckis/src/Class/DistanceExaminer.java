/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Roman Giruckis
 */
public class DistanceExaminer {
    private List<User> users = new ArrayList<>();
    private List<Question> questionBank = new ArrayList<>();
    public User currentUser;

    public void registerUser(String name, String login, String password, String role) {
        if (role.equalsIgnoreCase("teacher")) {
            users.add(new Teacher(name, login, password));
        } else {
            users.add(new Student(name, login, password));
        }
    }

    public User loginUser(String login, String password) {
        for (User user : users) {
            if (user.authenticate(login, password)) {
                currentUser = user;
                return user;
            }
        }
        return null;
    }

    public List<Student> getAllStudentResults() {
        List<Student> results = new ArrayList<>();
        for (User user : users) {
            if (user instanceof Student) {
                results.add((Student) user);
            }
        }
        return results;
    }

    public List<Double> getAllScores() {
        List<Double> scores = new ArrayList<>();
        for (Student s : getAllStudentResults()) {
            scores.add(s.User());
        }
        return scores;
    }

    public void saveToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt"))) {
            for (User user : users) {
                String role = (user instanceof Teacher) ? "teacher" : "student";
                writer.write(user.getFullName() + ";" + user.getLogin() + ";" + user.getPassword() + ";" + role);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadFromFile() {
        users.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 4) {
                    registerUser(parts[0], parts[1], parts[2], parts[3]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
