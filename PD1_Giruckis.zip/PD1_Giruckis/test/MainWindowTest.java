/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class MainWindowTest {

    private static File tempLoginFile;

    @BeforeClass
    public static void setup() throws IOException {
        tempLoginFile = File.createTempFile("LoginPassword", ".txt");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(tempLoginFile))) {
            writer.write("Gunars,Gravitis,Alien,123,student\n");
        }
    }

    @AfterClass
    public static void teardown() {
        if (tempLoginFile.exists()) {
            tempLoginFile.delete();
        }
    }

    @Test
    public void testIsFieldEmpty() {
        assertTrue(UserService.isFieldEmpty("qwe", "", "321"));
        assertFalse(UserService.isFieldEmpty("qwe", "321", "zxc"));
    }

    @Test
    public void testIsValidLength() {
        assertTrue(UserService.isValidLength("Gunars", 3, 15));
        assertFalse(UserService.isValidLength("zx", 3, 15));
        assertFalse(UserService.isValidLength("SUPER_SUPER_PUPER_LOOONG_NAME", 3, 15));
    }

    @Test
    public void testPasswordsMatch() {
        assertTrue(UserService.passwordsMatch("123", "123"));
        assertFalse(UserService.passwordsMatch("123", "Alien123"));
    }

    @Test
    public void testUserExists() throws IOException {
        assertTrue(UserService.userExists("Alien", tempLoginFile));
        assertFalse(UserService.userExists("Megaladon", tempLoginFile));
    }

    @Test
    public void testLoginCorrect() throws IOException {
        assertTrue(UserService.loginCorrect("Alien", "123", tempLoginFile));
        assertFalse(UserService.loginCorrect("Megaladon", "Alien123", tempLoginFile));
    }
    
    
    public class UserService {

        public static boolean isFieldEmpty(String... fields) {
            for (String field : fields) {
                if (field == null || field.trim().isEmpty()) return true;
            }
            return false;
        }

        public static boolean isValidLength(String input, int min, int max) {
            return input != null && input.length() >= min && input.length() <= max;
        }

        public static boolean passwordsMatch(String pass1, String pass2) {
            return pass1 != null && pass1.equals(pass2);
        }

        public static boolean userExists(String username, File file) throws IOException {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length > 2 && parts[2].trim().equals(username.trim())) {
                        return true;
                    }
                }
            }
            return false;
        }

        public static boolean loginCorrect(String username, String password, File file) throws IOException {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length >= 4 &&
                        parts[2].trim().equals(username) &&
                        parts[3].trim().equals(password)) {
                        return true;
                    }
                }
            }
            return false;
        } 
    }
}